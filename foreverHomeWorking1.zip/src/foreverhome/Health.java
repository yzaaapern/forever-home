/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package foreverhome;

/**
 *
 * @author annga
 */
public class Health extends Interaction 
{
    public Health(String trickName, int levelUnlocked, String interactionDesc)
    {
        super(trickName, levelUnlocked, "Health", interactionDesc);
    }
}
